// Created by iWeb 3.0.4 local-build-20121111

setTransparentGifURL('Media/transparent.gif');function applyEffects()
{var registry=IWCreateEffectRegistry();registry.registerEffects({stroke_0:new IWStrokeParts([{rect:new IWRect(-2,0,4,256),url:'Indian_Classical_Singing_files/stroke.png'},{rect:new IWRect(-2,-2,4,2),url:'Indian_Classical_Singing_files/stroke_1.png'},{rect:new IWRect(2,-2,304,2),url:'Indian_Classical_Singing_files/stroke_2.png'},{rect:new IWRect(306,-2,4,2),url:'Indian_Classical_Singing_files/stroke_3.png'},{rect:new IWRect(306,0,4,256),url:'Indian_Classical_Singing_files/stroke_4.png'},{rect:new IWRect(306,256,4,3),url:'Indian_Classical_Singing_files/stroke_5.png'},{rect:new IWRect(2,256,304,3),url:'Indian_Classical_Singing_files/stroke_6.png'},{rect:new IWRect(-2,256,4,3),url:'Indian_Classical_Singing_files/stroke_7.png'}],new IWSize(308,257))});registry.applyEffects();}
function hostedOnDM()
{return false;}
function onPageLoad()
{loadMozillaCSS('Indian_Classical_Singing_files/Indian_Classical_SingingMoz.css')
adjustLineHeightIfTooBig('id1');adjustFontSizeIfTooBig('id1');adjustLineHeightIfTooBig('id2');adjustFontSizeIfTooBig('id2');adjustLineHeightIfTooBig('id3');adjustFontSizeIfTooBig('id3');adjustLineHeightIfTooBig('id4');adjustFontSizeIfTooBig('id4');adjustLineHeightIfTooBig('id5');adjustFontSizeIfTooBig('id5');adjustLineHeightIfTooBig('id6');adjustFontSizeIfTooBig('id6');fixAllIEPNGs('Media/transparent.gif');Widget.onload();applyEffects()}
function onPageUnload()
{Widget.onunload();}
